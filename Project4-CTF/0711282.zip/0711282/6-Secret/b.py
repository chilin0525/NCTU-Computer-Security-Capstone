print("%p "*40)
