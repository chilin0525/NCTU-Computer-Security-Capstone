#!/bin/bash

strings time_will_stop | grep FLAG
